function [result_img, H, num_inliers, residual] = ...
    stitch_pair (image, target_image, sift_r, ...
    harris_r, harris_thresh, harris_sigma, num_putative_matches, ransac_n)

image_bw = im2single(rgb2gray(image));
target_image_bw = im2single(rgb2gray(target_image));


%% Feature Detection 
[cim, left_Y, left_X] = harris(image_bw, harris_sigma, ...
    harris_thresh, harris_r, 0);
[cim2, right_Y, right_X] = harris(target_image_bw, harris_sigma, ...
    harris_thresh, harris_r, 0);


%% Feature stored as keypoints
image_keypoint = cat(2, left_X, left_Y, ...
    repmat(sift_r, length(left_X), 1));
target_image_keypoint = cat(2, right_X, right_Y, ...
    repmat(sift_r, length(right_X), 1));


%% Feature Descriptor using SIFT
[image_descriptor_loc, left_descriptors] = ...
    vl_sift_wrapper(image_bw, image_keypoint);
[target_image_descriptor_loc, right_descriptors] = ...
    vl_sift_wrapper(target_image_bw, target_image_keypoint);


%% Feature Matching 
[left_matches, right_matches] = ...
    select_putative_matches(left_descriptors, right_descriptors, num_putative_matches);

%% Feature Correspondence using RANSAC
XY = image_descriptor_loc(left_matches,:);
XY_target = target_image_descriptor_loc(right_matches,:);

[H, num_inliers, residual] = ransac(XY, XY_target, ransac_n, ...
    @fit_homography, @homography_transform);


%% Resultanat Image
result_img = stitch(image, H, target_image);

end